# Teerapada CV 🎶

เว็บไซต์พอร์ตโฟลิโอส่วนตัวของ **ธีรภาดา ชุมพล (Teerapada Chumpol)**  
สร้างขึ้นด้วย HTML + Bootstrap 5

## 🔧 วิธีอัปโหลดขึ้น GitHub Pages

1. เข้า GitHub และสร้าง repository ชื่อ **teerapada-cv**
2. อัปโหลดไฟล์ทั้งหมดจากโฟลเดอร์นี้ขึ้นไป (รวมถึงโฟลเดอร์ `assets/`)
3. ไปที่ Settings → Pages  
   ในส่วน "Build and deployment" เลือก:
   - Source: `Deploy from a branch`
   - Branch: `main` (หรือ `master`) → `/ (root)`
4. รอสักครู่ จากนั้นเว็บจะเปิดใช้งานที่ลิงก์:  
   👉 `https://<username>.github.io/teerapada-cv/cv1.html`

## 📂 โครงสร้างไฟล์
```
teerapada-cv/
├── cv1.html
├── README.md
└── assets/
    ├── tee.jpg
    ├── song1.jpg
    ├── cover1.jpg
    └── cover2.jpg
```

> 🖼️ ใส่ภาพของคุณในโฟลเดอร์ `assets/` แล้วใช้ชื่อไฟล์ให้ตรงกับในโค้ด
